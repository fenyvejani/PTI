﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algolyze.Model
{
    // Another specific File class
    class FileLoad
    {
        // Project's direcotry (debug-bin)
        private string baseDirectory;

        // Sort for .txt only
        private string filesType;
        private string title;
        
        // Getters - Setters
        public string BaseDirectory => baseDirectory;
        public string FilesType => filesType;
        public string Title => title;

        // Constructor
        public FileLoad()
        {
            // Project base directory
            this.baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            this.filesType = "*.txt";
            this.title = "Please pick a source file...";
        }

    }
}
