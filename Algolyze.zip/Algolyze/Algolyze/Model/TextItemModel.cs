﻿using Algolyze.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace Algolyze.Model
{
    class TextItemModel : ViewModelBase
    {
        // For the Textboxes in Sorts
        private string strText;
        public string StrText
        {
            get { return strText; }
            set
            {
                strText = value;
                OnPropertyChanged();
            }
        }

        // For highlight base is white
        private Brush background = Brushes.White;
        public Brush Background
        {
            get { return background; }
            set
            {
                background = value;
                OnPropertyChanged();
            }
        }
    }
}
