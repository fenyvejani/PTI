﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Algolyze.View;
using System.Windows;

namespace Algolyze.Model
{
    class NumberModel
    {
        // List stores the numbers from file
        private static List<int> numbers;

        // For randoms
        private List<string> nums;
        public static List<int> Numbers => numbers;

        // Init the static field 
        public static void initNumbers(FileInfoModel file)
        {
            numbers = new List<int>();

            // Iteration in the params file
            foreach (string f in File.ReadLines(file.FileName))
            {
                // Parse
                int tmp = int.Parse(f);
                numbers.Add(tmp);
            }
        }

        // Generating random numbers and save it to file
        // Returns the path
        public string ModelGenerateFullRandom()
        {
            Random rnd = new Random();
            nums = new List<string>();

            // Generates random size
            int numLength = rnd.Next(1, 51);
            for (int i = 0; i < numLength; i++)
            {
                // Generates random nums 1-100
                nums.Add($"{rnd.Next(1, 101)}");
            }
            string path = $"{numLength}_{DateTime.Now.Year.ToString()}_FullRnd";
            File.WriteAllLines($"{path}.txt", nums);
            nums.Clear();
            return path;
        }

        // AddRandom numbers from the given ViewModel params
        public string ModelAddRandom(bool done, string ArraySize, string FromText, string ToText)
        {
            nums = new List<string>();
            string path = "";
            if (done)
            {
                try
                {
                    // Array size
                    int n = int.Parse(ArraySize);
                    // From
                    int a = int.Parse(FromText);
                    // To
                    int b = int.Parse(ToText);

                    // Generates random size
                    for (int i = 0; i < n; i++)
                    {
                        // Generates random nums 1-100
                        int tmp = new Random().Next(a, b + 1);
                        nums.Add($"{tmp}");
                    }


                    // Save to txt
                    path = $"{n}_{DateTime.Now.Year.ToString()}_Rnd";
                    File.WriteAllLines($"{path}.txt", nums);
                }
                catch(Exception e) 
                {

                }
            }
            nums.Clear();
            return path;
        }

        public string ModelAddManual(bool success, string inputArray)
        {
            // Gives the full array's content
            string path = "";

            nums = new List<string>();
            if (success)
            {
                // Try-catch for the format
                try
                {
                    string[] stringNums = inputArray.Split(',');
                    foreach (var s in stringNums)
                    {
                        int i = int.Parse(s);
                        nums.Add(s);
                    }

                    // Save to txt
                    path = $"{nums.Count}_{DateTime.Now.Year.ToString()}_Mnl";
                    File.WriteAllLines($"{path}.txt", nums);
                }
                catch (Exception ex)
                {
                }
            }
            nums.Clear();
            return path;
        }
    }
}
