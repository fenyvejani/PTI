﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Algolyze.Model
{
    // Specific File class
    class FileInfoModel
    {
        private string fileName;
        private DateTime modifiedDate;
        private string fileSize;

        // Getter - Setters
        public string FileName
        {
            get { return fileName; }
            set { fileName = value; }
        }
        public DateTime ModifiedDate
        {
            get { return modifiedDate; }
            set { modifiedDate = value; }
        }
        public string FileSize
        {
            get { return fileSize; }
            set { fileSize = value; }
        }

        // Params FileInfo object
        public FileInfoModel(FileInfo f)
        {
            FileName = f.Name;
            ModifiedDate = f.LastWriteTime;

            // Convert to KB
            FileSize = $"{f.Length / 1024.0:F2} KB";
        }
    }
}
