﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Media;

namespace Algolyze.Model
{
    class BubbleSortModel
    {
        // Container for numbers from file
        public List<int> Numbers { get; set; }

        // TexItems
        public List<TextItemModel> Texts { get; set; }
        // Pause checker
        public bool IsPaused { get; set; }

        // Delay in miliseconds
        public int Delay { get; set; }

        // Init. default values
        public BubbleSortModel()
        {
            // Getting datas from static method
            Numbers = NumberModel.Numbers;
            // Default delay
            Delay = 1000;
            // New Text container
            Texts = new List<TextItemModel>();
        }

        // Init. the Texts from ViewModel
        public void InitTexts(List<TextItemModel> texts)
        {
            this.Texts = texts;
        }

        // Async method, for the pause
        public async Task WaitForPause(CancellationToken cancellationToken)
        {
            while (IsPaused)
            {
                // Checking, while paused => cancel 
                cancellationToken.ThrowIfCancellationRequested();
                await Task.Delay(100, cancellationToken); // Bit delay
            }
        }

        // Decesion about swaps index
        public bool Swapping(int index)
        {
            return int.Parse(Texts[index].StrText) > int.Parse(Texts[index + 1].StrText);
        }

    }
}
