﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Algolyze.Model
{
    class InsertionSortModel
    {
        // Container for numbers from file
        public List<int> Numbers { get; set; }

        // TexItems
        public List<TextItemModel> Texts { get; set; }
        // Pause checker
        public bool IsPaused { get; set; }

        // Delay in miliseconds
        public int Delay { get; set; }
        public InsertionSortModel()
        {
            // Getting datas from static method
            Numbers = NumberModel.Numbers;
            // Default delay
            Delay = 1000;
            // New Text container
            Texts = new List<TextItemModel>();
        }
        // Init. the Texts from ViewModel
        public void InitTexts(List<TextItemModel> texts)
        {
            this.Texts = texts;
        }

        public async Task WaitForPause(CancellationToken cancellationToken)
        {
            while (IsPaused)
            {
                // Checking, while paused => cancel 
                cancellationToken.ThrowIfCancellationRequested();
                await Task.Delay(100, cancellationToken); // Bit delay
            }
        }
        // Decesion about swaps index
        public bool Swapping(int index, TextItemModel text)
        {
            return int.Parse(Texts[index].StrText) > int.Parse(text.StrText);
        }

    }
}
