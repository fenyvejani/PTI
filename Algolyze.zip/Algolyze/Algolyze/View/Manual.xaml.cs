﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Algolyze.View
{
    /// <summary>
    /// Interaction logic for Manual.xaml
    /// </summary>
    public partial class Manual : Window
    {
        public string InputArray { get; set; }
        public bool Success { get; set; }
        public Manual()
        {
            InitializeComponent();
            OkBtn.IsEnabled = false;
            Success = false;
        }

        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void OkBtn_Click(object sender, RoutedEventArgs e)
        {
            InputArray = array.Text;
            Close();
        }

        private void array_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!string.IsNullOrEmpty(array.Text))
            {
                OkBtn.IsEnabled = true;
                Success = true;
            }
            else
            {
                OkBtn.IsEnabled = false;
            }
        }
    }
}
