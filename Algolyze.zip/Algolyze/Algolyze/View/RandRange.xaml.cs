﻿using Algolyze.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Algolyze.View
{
    /// <summary>
    /// Interaction logic for RandRange.xaml
    /// </summary>
    public partial class RandRange : Window
    {
        // Input fields
        public string FromText { get; set; }
        public string ToText { get; set; }
        public string ArraySize { get; set; }
        public bool Done { get; set; }
        public RandRange()
        {
            InitializeComponent();
            OkBtn.IsEnabled = false;
            Done = false;
        }

        // One of them is NULL or Empty the OK button is disabled!
        private void from_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Success())
            {
                OkBtn.IsEnabled = true;
            }
            else
            {
                OkBtn.IsEnabled = false;
            }
        }

        private void to_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Success())
            {
                OkBtn.IsEnabled = true;
            }
            else
            {
                OkBtn.IsEnabled = false;
            }
        }

        private void OkBtn_Click(object sender, RoutedEventArgs e)
        {
            // Inputs
            ArraySize = arrayLength.Text;
            FromText = from.Text;
            ToText = to.Text;
            Done = true;
            Close();
        }

        // Close the window
        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void arrayLength_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Success())
            {
                OkBtn.IsEnabled = true;
            }
            else
            {
                OkBtn.IsEnabled = false;
            }
        }

        private bool Success()
        {
            if (string.IsNullOrEmpty(arrayLength.Text) || string.IsNullOrEmpty(to.Text) ||
                string.IsNullOrEmpty(from.Text)) return false;
            else return true;
        }
    }
}
