﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using System.Windows;
using System.Windows.Input;
using Algolyze.Model;
using Algolyze.Utilities;
using Algolyze.View;

namespace Algolyze.ViewModel
{
    // Navigation navigates us to another UserConrol
    class NavigationVM : ViewModelBase
    {
        // Actual Window
        private object _currentView;
        public object CurrentView
        {
            get { return _currentView; }
            // Checking the properties
            set { _currentView = value; OnPropertyChanged(); }
        }

        // Commands (UserControls)
        public ICommand HomeCommand { get; set; }
        public ICommand GenerateCommand { get; set; }
        public ICommand AboutCommand { get; set; }
        public ICommand BubbleSortCommand { get; set; }
        public ICommand StatisticsCommand { get; set; }
        public ICommand LoadCommand { get; set; }
        public ICommand InsertionSortCommand { get; set; }

        // Actual view loads the new UserControl
        private void Home(object obj) => CurrentView = new HomeVM();
        private void Generate(object obj) => CurrentView = new GenerateVM();
        private void Load(object obj) => CurrentView = new LoadVM();
        private void BubbleSort(object obj)
        {
            if (NumberModel.Numbers != null && NumberModel.Numbers.Count > 1)
            {
                CurrentView = new BubbleSortVM();
            }
            else
            {
                MessageBox.Show($"List is currently empty OR lesser than 2 elements\nPlease LOAD IT first!",
                                    "LIST PROBLEM", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void InsertionSort(object obj)
        {
            if (NumberModel.Numbers != null && NumberModel.Numbers.Count > 1)
            {
                CurrentView = new InsertionSortVM();
            }
            else
            {
                MessageBox.Show($"List is currently empty OR lesser than 2 elements\nPlease LOAD IT first!",
                                    "LIST PROBLEM", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        /*
        private void About(object obj) => CurrentView = new AboutVM();
        private void Sort(object obj) => CurrentView = new SortVM();
        private void Statistics(object obj) => CurrentView = new StatisticsVM();*/

        public NavigationVM()
        {
            // Init.
            HomeCommand = new RelayCommand(Home);
            GenerateCommand = new RelayCommand(Generate);
            LoadCommand = new RelayCommand(Load);
            BubbleSortCommand = new RelayCommand(BubbleSort);
            InsertionSortCommand = new RelayCommand(InsertionSort);

            // Startup Page
            CurrentView = new HomeVM();
        }
    }
}
