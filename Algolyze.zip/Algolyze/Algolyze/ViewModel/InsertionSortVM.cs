﻿using Algolyze.Model;
using Algolyze.Utilities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;

namespace Algolyze.ViewModel
{
    class InsertionSortVM : ViewModelBase
    {
        // Fields
        private InsertionSortModel model;
        private ObservableCollection<TextItemModel> textItems;
        private int delay;
        private bool isResetActive = false;
        private bool isSlowActive = false;
        private bool isSpeedActive = false;
        private bool isPlayOrPausedActive = false;
        private bool sortEnable = true;
        private string pauseButtonText = "Pause|Play";
        private CancellationTokenSource cancel;
        private int sortedPart;
        private bool isDone;

        // Getter - Setters
        public int SortedPart
        {
            get { return sortedPart; }
            set
            {
                if (sortedPart != value)
                {
                    sortedPart = value;
                    OnPropertyChanged();
                }
            }
        }
        public ObservableCollection<TextItemModel> TextItems
        {
            get { return textItems; }
            set { textItems = value; OnPropertyChanged(); }
        }
        public int Delay
        {
            get { return delay; }
            set { delay = value; OnPropertyChanged(); }
        }

        public bool SortEnable
        {
            get { return sortEnable; }
            set { sortEnable = value; OnPropertyChanged(); }
        }

        public bool IsSlowActive
        {
            get { return isSlowActive; }
            set { isSlowActive = value; OnPropertyChanged(); }
        }

        public bool IsSpeedActive
        {
            get { return isSpeedActive; }
            set { isSpeedActive = value; OnPropertyChanged(); }
        }

        public bool IsPlayOrPausedActive
        {
            get { return isPlayOrPausedActive; }
            set { isPlayOrPausedActive = value; OnPropertyChanged(); }
        }

        public bool IsResetActive
        {
            get { return isResetActive; }
            set { isResetActive = value; OnPropertyChanged(); }
        }
        public string PauseButtonText
        {
            get { return pauseButtonText; }
            set { pauseButtonText = value; OnPropertyChanged(); }
        }
        public bool IsDone
        {
            get { return isDone; }
            set { isDone = value; OnPropertyChanged();}
        }

        // For iterations
        private int i = 0;
        private int j = 0;
        // Commands
        public ICommand ResetCommand { get; set; }
        public ICommand SortCommand { get; set; }
        public ICommand PausePlayCommand { get; set; }
        public ICommand SlowCommand { get; set; }
        public ICommand SpeedCommand { get; set; }

        // Initialize
        public InsertionSortVM()
        {
            TextItems = new ObservableCollection<TextItemModel>();
            LoadData();
            InitializeCommands();
        }

        private void DeactivateBools()
        {
            Delay = model.Delay;
            model.IsPaused = false;
            SortEnable = false;
            IsSlowActive = false;
            IsSpeedActive = false;
            IsPlayOrPausedActive = false;
            IsResetActive = true;
            IsDone = false;
        }
        // Default loading
        private void LoadData()
        {
            model = new InsertionSortModel();
            TextItems.Clear();
            Delay = model.Delay;
            model.IsPaused = false;
            SortEnable = true;
            IsSlowActive = false;
            IsSpeedActive = false;
            IsPlayOrPausedActive = false;
            IsResetActive = false;
            IsDone = false;
            i = 1;
            j = 0;
            foreach (int number in model.Numbers)
            {
                TextItems.Add(new TextItemModel { StrText = number.ToString() });
            }
            model.InitTexts(TextItems.ToList());
        }

        // Commands init
        private void InitializeCommands()
        {
            SortCommand = new RelayCommand(InsertSort);
            ResetCommand = new RelayCommand(Reset);
            PausePlayCommand = new RelayCommand(PauseOrPlay);
            SlowCommand = new RelayCommand(Slow);
            SpeedCommand = new RelayCommand(Speed);
        }


        // Sort command method
        private async void InsertSort(object obj)
        {
            // Disable the sort buttin
            SortEnable = false;
            IsSlowActive = true;
            IsSpeedActive = true;
            IsPlayOrPausedActive = true;
            IsResetActive = true;
            // Cancel dispose
            CancelDispose();
            cancel = new CancellationTokenSource();
            try
            {
                await Sort(cancel.Token);
            }
            catch (OperationCanceledException)
            {
                MessageBox.Show($"Sort is interrupted!\nReset is done!",
                 "RESET", MessageBoxButton.OK, MessageBoxImage.Warning);
                SortEnable = true;
            }
            finally
            {
                CancelDispose();
            }
        }
        // Main sort
        private async Task Sort(CancellationToken cancel)
        {
            int N = TextItems.Count;
            for (; i < N; i++)
            {
                TextItemModel key = TextItems[i];

                // Interrupt if asked
                cancel.ThrowIfCancellationRequested();
                // Pause check
                await model.WaitForPause(cancel);

                key.Background = Brushes.LightBlue;  // Highlight the key element
                string keyText = key.StrText;  // Save the key element's text
                j = i - 1; // Back

                await Task.Delay(Delay);  // Delay


                // Checking the elements, compare
                while (j >= 0 && int.Parse(TextItems[j].StrText) > int.Parse(keyText))
                {
                    // Interrupt if asked
                    cancel.ThrowIfCancellationRequested();
                    // Pause check
                    await model.WaitForPause(cancel);

                    TextItems[j].Background = Brushes.LightCoral;  // Highlight the wrong element
                    j--;

                    // Interrupt if asked
                    cancel.ThrowIfCancellationRequested();
                    // Pause check
                    await model.WaitForPause(cancel);

                    await Task.Delay(Delay);  // Delay
                }

                await MoveRight(cancel);

                // Key insert
                TextItems[j + 1].StrText = keyText;
                TextItems[j + 1].Background = Brushes.White; // Default color

                // Default color for all cards
                DefaultUIUpdate();

                await Task.Delay(Delay);  // Delay
            }
            IsDone = true;
            SortDone();
        }

        private void SortDone()
        {
            if(IsDone)
            {
                MessageBox.Show($"Sort is done!\nNumbers are in order!",
                        "DONE", MessageBoxButton.OK, MessageBoxImage.Information);
                DeactivateBools();
            }
        }
        private async Task MoveRight(CancellationToken cancel)
        {
            // Interrupt if asked
            cancel.ThrowIfCancellationRequested();
            // Pause check
            await model.WaitForPause(cancel);

            // Move right the elements
            for (int k = i - 1; k > j; k--)
            {
                string tmp = TextItems[k].StrText;
                TextItems[k].StrText = "-->";

                // Interrupt if asked
                cancel.ThrowIfCancellationRequested();
                // Pause check
                await model.WaitForPause(cancel);

                TextItems[k + 1].Background = Brushes.Yellow;  // Yellow highlight the moving elements
                TextItems[k + 1].StrText = tmp;  // Only the values switch

                // Interrupt if asked
                cancel.ThrowIfCancellationRequested();
                // Pause check
                await model.WaitForPause(cancel);

                await Task.Delay(Delay);  // Delay
            }
        }
        private void DefaultUIUpdate()
        {
            foreach (var item in TextItems)
            {
                item.Background = Brushes.White;
            }
        }

        // Slow command method
        private void Slow(object obj)
        {
            Delay += 100;
        }

        // Pause or Play command method
        private void PauseOrPlay(object obj)
        {
            model.IsPaused = !model.IsPaused;
            PauseButtonText = model.IsPaused ? "Continue" : "Pause";
        }

        // Speed command method
        private void Speed(object obj)
        {
            if (Delay > 100) Delay -= 100;
        }

        // Dispose the async
        private void CancelDispose()
        {
            // If async is running
            if (cancel != null)
            {
                cancel.Cancel();
                cancel.Dispose();
                cancel = null;
            }
        }

        // Reset command method
        private void Reset(object obj)
        {
            CancelDispose();
            cancel = new CancellationTokenSource();
            LoadData();
        }
    }
}
