﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Algolyze.Utilities;
using System.IO;
using Algolyze.View;
using System.Windows;
using Microsoft.Win32;
using Algolyze.Model;
using System.Collections.ObjectModel;
using System.Reflection.Metadata;

namespace Algolyze.ViewModel
{
    class LoadVM : ViewModelBase
    {
        private FileLoad fl;
        // Observable for our ListView
        private ObservableCollection<FileInfoModel> textFiles;
        // File seleection
        private FileInfoModel selectedFile;
        public ObservableCollection<FileInfoModel> TextFiles
        {
            get { return textFiles; }
            set { textFiles = value; }
        }

        public FileInfoModel SelectedFile
        {
            get { return selectedFile; }
            set { selectedFile = value; }
        }
        public ICommand LoadFileCommand { get; set; }
        public ICommand SelectFileCommand { get; set; }
        public ICommand DeleteFileCommand { get; set; }

        // Implement
        private void LoadFile(object obj)
        {
            //OpenFileDialog fileDialog = new OpenFileDialog();
            TextFiles.Clear();
            // Load to ListView
            string[] files = Directory.GetFiles(fl.BaseDirectory, fl.FilesType);
            foreach(string f in files)
            {
                FileInfo fileInfo = new FileInfo(f);
                FileInfoModel fim = new FileInfoModel(fileInfo);
                TextFiles.Add(fim);
            }
        }

        private void SelectFile(object obj)
        {
            // Selected file
            if(SelectedFile != null)
            {
                // Loaded to an array
                try
                {
                    NumberModel.initNumbers(SelectedFile);
                    MessageBox.Show("Selected txt loaded to an array!", "LOADED", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch(Exception ex)
                {
                    NumberModel.Numbers.Clear();
                    MessageBox.Show($"Wrong FILE FORMAT!\nPlease check it!",
                    "WRONG FILE", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else MessageBox.Show("You have to select a file first!", "NO SELECTION", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void DeleteFile(object obj)
        {
            // Check file
            if (SelectedFile != null)
            {
                // Get full path
                string fullPath = Path.Combine(fl.BaseDirectory, SelectedFile.FileName);
                if (File.Exists(fullPath))
                {
                    // Delete from folder
                    File.Delete(fullPath);
                    // Collection
                    TextFiles.Remove(SelectedFile);
                    // Reset
                    SelectedFile = null;
                    // Message
                    MessageBox.Show("Delete is complete!","DELETE",MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            // No selection case
            else MessageBox.Show("You have to select a file first!", "NO SELECTION", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        public LoadVM()
        {
            // Init. Commands
            LoadFileCommand = new RelayCommand(LoadFile);
            SelectFileCommand = new RelayCommand(SelectFile);
            DeleteFileCommand = new RelayCommand(DeleteFile);
            // Init props.
            fl = new FileLoad();
            TextFiles = new ObservableCollection<FileInfoModel>();
        }
    }
}
