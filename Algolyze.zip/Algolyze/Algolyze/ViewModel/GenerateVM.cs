﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Collections.ObjectModel;
using Algolyze.Utilities;
using System.IO;
using Algolyze.View;
using System.Windows;
using System.Windows.Shapes;
using Algolyze.Model;

namespace Algolyze.ViewModel
{
    class GenerateVM : ViewModelBase
    {
        private NumberModel numberModel;
        public ICommand AddFullRandomCommand { get; set; }
        public ICommand AddRandomCommand { get; set; }
        public ICommand AddManualCommand { get; set; }

        // Implement the logic

        private void AddFullRandom (object obj)
        {
            // NumberModel method returns a string
            MessageBox.Show($"Successful!\nFilename: {numberModel.ModelGenerateFullRandom()}.txt",
                    "DONE", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        private void AddRandom(object obj)
        {
            // Window open
            RandRange rangeWindow = new RandRange();
            rangeWindow.ShowDialog();

            // Using model's method => returns string
            string path = numberModel.ModelAddRandom(rangeWindow.Done, rangeWindow.ArraySize,
                rangeWindow.FromText, rangeWindow.ToText);

            // Check the string
            if(!string.IsNullOrEmpty(path))
            {
                MessageBox.Show($"Successful!\nFilename: {path}.txt",
                    "DONE", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show($"Iterrupted!\nAdd Random is interrupted!",
                "INTERRUPT", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void AddManual(object obj)
        {
            // Gives the full array's content
            Manual manualWindow = new Manual();
            manualWindow.ShowDialog();

            // Using model's method
            string path = numberModel.ModelAddManual(manualWindow.Success,
                manualWindow.InputArray);

            // Check the string
            if(!string.IsNullOrEmpty(path))
            {
                MessageBox.Show($"Successful!\nFilename: {path}.txt",
                    "DONE", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show($"Wrong INPUT or FORMAT!\nPlease check it!",
                    "WRONG SYNTAX", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Init
        public GenerateVM()
        {
            numberModel = new NumberModel();
            AddFullRandomCommand = new RelayCommand(AddFullRandom);
            AddRandomCommand = new RelayCommand(AddRandom);
            AddManualCommand = new RelayCommand(AddManual);
        }
    }
}
