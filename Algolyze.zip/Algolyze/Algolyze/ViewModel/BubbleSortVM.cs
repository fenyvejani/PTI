﻿using Algolyze.Model;
using Algolyze.Utilities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Algolyze.ViewModel
{
    class BubbleSortVM : ViewModelBase
    {
        // Fields
        private BubbleSortModel model;
        private ObservableCollection<TextItemModel> textItems;
        private int delay;
        private bool isResetActive = false;
        private bool isSlowActive = false;
        private bool isSpeedActive = false;
        private bool isPlayOrPausedActive = false;
        private bool sortEnable = true;
        private string pauseButtonText = "Pause|Play";
        private CancellationTokenSource cancel;
        private bool isDone;

        // Getter - Setters
        public ObservableCollection<TextItemModel> TextItems
        {
            get { return textItems; }
            set { textItems = value; OnPropertyChanged(); }
        }
        public int Delay
        {
            get { return delay; }
            set { delay = value; OnPropertyChanged(); }
        }

        public bool SortEnable
        {
            get { return sortEnable; }
            set { sortEnable = value; OnPropertyChanged(); }
        }

        public bool IsSlowActive
        {
            get { return isSlowActive; }
            set { isSlowActive = value; OnPropertyChanged(); }
        }

        public bool IsSpeedActive
        {
            get { return isSpeedActive; }
            set { isSpeedActive = value; OnPropertyChanged(); }
        }

        public bool IsPlayOrPausedActive
        {
            get { return isPlayOrPausedActive; }
            set { isPlayOrPausedActive = value; OnPropertyChanged(); }
        }

        public bool IsResetActive
        {
            get { return isResetActive; }
            set { isResetActive = value; OnPropertyChanged(); }
        }
        public string PauseButtonText
        {
            get { return pauseButtonText; }
            set { pauseButtonText = value; OnPropertyChanged(); }
        }
        public bool IsDone
        {
            get { return isDone; }
            set { isDone = value; OnPropertyChanged(); }
        }

        // For iterations
        private int i = 0;
        private int j = 0;

        // Commands
        public ICommand ResetCommand { get; set; }
        public ICommand SortCommand { get; set; }
        public ICommand PausePlayCommand { get; set; }
        public ICommand SlowCommand { get; set; }
        public ICommand SpeedCommand { get; set; }

        // Initialize
        public BubbleSortVM()
        {
            TextItems = new ObservableCollection<TextItemModel>();
            LoadData();
            InitializeCommands();
        }
        private void DeactivateBools()
        {
            Delay = model.Delay;
            model.IsPaused = false;
            SortEnable = false;
            IsSlowActive = false;
            IsSpeedActive = false;
            IsPlayOrPausedActive = false;
            IsResetActive = true;
            IsDone = false;
        }

        // Default loading
        private void LoadData()
        {
            model = new BubbleSortModel();
            TextItems.Clear();
            Delay = model.Delay;
            model.IsPaused = false;
            SortEnable = true;
            IsSlowActive = false;
            IsSpeedActive = false;
            IsPlayOrPausedActive = false;
            IsResetActive = false;
            TextItems.Clear();
            i = 0;
            j = 0;
            foreach (int number in model.Numbers)
            {
                TextItems.Add(new TextItemModel { StrText = number.ToString() });
            }
            model.InitTexts(TextItems.ToList());
        }

        // Commands init
        private void InitializeCommands()
        {
            SortCommand = new RelayCommand(BubbleSort);
            ResetCommand = new RelayCommand(Reset);
            PausePlayCommand = new RelayCommand(PauseOrPlay);
            SlowCommand = new RelayCommand(Slow);
            SpeedCommand = new RelayCommand(Speed);
        }


        // Sort command method
        private async void BubbleSort(object obj)
        {
            // Disable the sort buttin
            SortEnable = false;
            IsSlowActive = true;
            IsSpeedActive = true;
            IsPlayOrPausedActive = true;
            IsResetActive = true;
            // Cancel dispose
            CancelDispose();
            cancel = new CancellationTokenSource();
            try
            {
                await Sort(cancel.Token);
            }
            catch (OperationCanceledException)
            {
                MessageBox.Show($"Sort is interrupted!\nReset is done!",
                 "RESET", MessageBoxButton.OK, MessageBoxImage.Warning);
                SortEnable = true;
            }
            finally
            {
                CancelDispose();
            }
        }

        // Main sorting logic
        private async Task Sort(CancellationToken cancel)
        {
            // Our items count
            int N = TextItems.Count;

            // Continue the last checkpoint if paused
            for (; i < N - 1; i++)
            {
                // Interrupt if asked
                cancel.ThrowIfCancellationRequested();

                for (; j < N - i - 1; j++)
                {
                    // Interrupt if asked
                    cancel.ThrowIfCancellationRequested();

                    // Pause check
                    await model.WaitForPause(cancel);

                    ComparsionUIUpdate(j);

                    // Pause check
                    await model.WaitForPause(cancel);

                    await Task.Delay(Delay, cancel);

                    // Comparison
                    if (model.Swapping(j))
                    {
                        // Interrupt if asked
                        cancel.ThrowIfCancellationRequested();

                        // Pause check
                        await model.WaitForPause(cancel);

                        // Highlight
                        await DoSwap(j, cancel);
                    }

                    // Interrupt if asked
                    cancel.ThrowIfCancellationRequested();

                    // Pause check
                    await model.WaitForPause(cancel);

                    // Default
                    DefaultUIUpdate(j);

                    // Pause check
                    await model.WaitForPause(cancel);

                    await Task.Delay(Delay); // Delay
                }
                j = 0; // Reset 'j' for the next iteration of 'i'
            }
            IsDone = true;
            SortDone();
        }

        // Submethods for BubbleSort
        private void SortDone()
        {
            if (IsDone)
            {
                MessageBox.Show($"Sort is done!\nNumbers are in order!",
                        "DONE", MessageBoxButton.OK, MessageBoxImage.Information);
                DeactivateBools();
            }
        }
        // If swapping is true then swap them
        private async Task DoSwap(int index, CancellationToken cancel)
        {
            cancel.ThrowIfCancellationRequested();
            // Pause check
            await model.WaitForPause(cancel);

            // Highlight the elements
            TextItems[index].Background = Brushes.LightCoral;
            TextItems[index + 1].Background = Brushes.LightCoral;

            cancel.ThrowIfCancellationRequested();
            // Pause check
            await model.WaitForPause(cancel);

            await Task.Delay(Delay, cancel);

            // Swap
            string temp = TextItems[index].StrText;

            cancel.ThrowIfCancellationRequested();
            // Pause check
            await model.WaitForPause(cancel);

            TextItems[index].StrText = TextItems[index + 1].StrText;
            TextItems[index + 1].StrText = temp;

            cancel.ThrowIfCancellationRequested();
            // Pause check
            await model.WaitForPause(cancel);

            // Bit delay
            await Task.Delay(Delay, cancel);
        }

        // Highlighting the elements
        private void ComparsionUIUpdate(int index)
        {
            TextItems[index].Background = Brushes.LightBlue;
            TextItems[index + 1].Background = Brushes.LightBlue;
        }

        // Default background for the elements
        private void DefaultUIUpdate(int index)
        {
            TextItems[index].Background = Brushes.White;
            TextItems[index + 1].Background = Brushes.White;
        }

        // Slow command method
        private void Slow(object obj)
        {
            Delay += 100;
        }

        // Pause or Play command method
        private void PauseOrPlay(object obj)
        {
            model.IsPaused = !model.IsPaused;
            PauseButtonText = model.IsPaused ? "Continue" : "Pause";
        }

        // Speed command method
        private void Speed(object obj)
        {
            if (Delay > 100) Delay -= 100;
        }

        // Dispose the async
        private void CancelDispose()
        {
            // If async is running
            if (cancel != null)
            {
                cancel.Cancel();
                cancel.Dispose();
                cancel = null;
            }
        }

        // Reset command method
        private void Reset(object obj)
        {
            CancelDispose();
            cancel = new CancellationTokenSource();
            LoadData();
        }
    }
}
