Algolyze
-----------------------------------------------------------------------------------------------------------

Fontos!
A program futtatása 32bites vagy 64 bites windows 10 operációs rendszeren
hajtható végre, a stabil működés érdekében.

-----------------------------------------------------------------------------------------------------------

A program indítása:


1. Indítsa el a .exe fájlt és ugorjon az "Útmutató" részre.

2. Indítsa el a .sln fájlt és ugorjon az "Útmutató" részre.

-----------------------------------------------------------------------------------------------------------

Úmutató:


1.: Indítást követően válassza ki a Generate opciót.

2.: Válasszon ki egy tetszőleges menüpontot, ahogy szeretne adatot generálni.
    Megjegyzés: A program csak számsorozatot fogad el!

3.: Lépjen a Load Datas fülre és töltse be a kiválasztott állományt.

4.: Sikeres betöltés után, válasszon egy tetszőleges rendezési módszert.

5. Indítsa el a Sort gombbal a rendezést

6.: A rendezés menüben tudja gyorsítani, lassítani illetve megállítani a rendezést.

7.: Rendezés befejezését követően kattintson a Reset gombra, ha újra szeretné próbálni.

8.: Kellemes időtöltést!

-----------------------------------------------------------------------------------------------------------

További információért olvassa el a dokumentációt!
